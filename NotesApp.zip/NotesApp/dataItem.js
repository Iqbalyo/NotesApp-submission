

class DataItem extends HTMLElement {
    constructor() {
        super();

        this._data = {
            id: 0,
            title: 'NEED_TITLE',
            body: 'NEED_BODY',
            createdAt: 'NEED_createdAt',
            archived: 'NEED_archived',
        };

        this.style = document.createElement('style');

    }
    setData(value) {
        this._data['id'] = value.id;
        this._data['title'] = value.title;
        this._data['body'] = value.body;
        this._data['createdAt'] = value.createdAt;
        this._data['archived'] = value.archived;
        
        this.render();
    }

    connectedCallback() {
        this.render();
    }
    updateStyle() {
        this._style.textContent = `
        data-item {
            padding: 1rem 0.8rem;
            display: block;

            border-radius: 4px;
            box-shadow: 0 0 2px 2px #33333377;
        }
        
        .data__title {
            margin-block-start: 0;
            margin-block-end: 1rem;

            font-size: 1.3em;
            font-weight: bold;

        }
         p {
            margin-block-start: 0;
        }
        `;
    }
        render() {
            this.updateStyle();

            this.setAttribute('data-id', this._data.id);

            this.innerHTML = `
            ${this._style.outerHTML}

            <h5 class=".data__title">
            <a href="#">${this._data.title}</a>
            </h5>
            <div clas="data__body">
            <p>${this._data.body}</p>
            </div>
            ;`
        
        }
    }


customElements.define('data-item', DataItem);
