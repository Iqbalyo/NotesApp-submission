class dataList extends HTMLElement {
    constructor() {
        super();

        this._DataList = [];
        this._style = document.createElement('style');
    }

    setNoteList(value) {
        this._DataList = value;

        this.render();
    }
    connectedCallback(){
        this.render();  
    }
    updateStyle() {
        this._style.textContent = `
        data-list {
            display: grid;

            grid-template-columns: 1fr 1fr;
            gap: 1 rem;
        }
        `;
    }

    render() {
        this.updateStyle();
        const DataItemElements = this._DataList.map((item) => {
            
            const data = document.createElement('data-item');
            data.setData(item);
            return data;
        }) ;

        this.innerHTML = '';
        this.append(this._style, ...DataItemElements);
    }
   
}

customElements.define('data-list', dataList);